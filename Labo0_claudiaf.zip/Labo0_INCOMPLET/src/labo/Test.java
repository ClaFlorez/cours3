package labo;

public class Test {

    public static void main(String[] args) {

//        Travail à faire : (voir support du cours)
//1-	Installer l’environnement  de développement Netbeans et importer le projet.
//2-	Créer une adresse dans la classe Test en utilisant le 1er constructeur (voir les commentaires).
        Adresse monAdresse;
//3-	Affecter des valeurs à l’objet adresse créée.
        monAdresse = new Adresse(120, "QC", "DDO");
//4-	Afficher l’objet adresse crée.
        System.out.println(monAdresse.codePostal + " " + monAdresse.gouvernorat + " " + monAdresse.ville);
//5-	Modifier le code postal de cette adresse.
        monAdresse.codePostal = 130;
//6-	Afficher l’objet adresse modifié.
        System.out.println(monAdresse.codePostal + " " + monAdresse.gouvernorat + " " + monAdresse.ville);
//7-	Créer une adresse dans la classe Test en utilisant le 2ème constructeur  (voir les commentaires).
        Adresse mon2Adresse;
        mon2Adresse = new Adresse(140, "Pierrefonds");
//8-	Modifier la ville de cette adresse.
        mon2Adresse.ville = "Verdum";
//9-	Afficher l’objet adresse modifié.
        System.out.println(mon2Adresse.codePostal + " " + mon2Adresse.gouvernorat + " " + mon2Adresse.ville);

//10-	Ecrivez la classe Chercheur en ajoutant ses attributs.


//11-	Créer un Chercheur dans la classe Test en utilisant le même type de constructeur dans la classe Adresse C1. 

        Chercheur mon1Chercheur;

//12-	Affecter des valeurs à ce chercheur.

        mon1Chercheur = new Chercheur("Perez", "étudiante", 10000);
//13-	Afficher toutes les informations relatives à ce chercheur.

        System.out.println(mon1Chercheur.nom + " " + mon1Chercheur.poste + " " + mon1Chercheur.ordinateur);

//14-	Déclarer dans la classe Chercheur un deuxième constructeur paramétré.

        Chercheur mon2Chercheur = new Chercheur("Lopez");
//15-	Afficher toutes les informations relatives à ce chercheur.

        System.out.println(mon2Chercheur.nom + " " + mon2Chercheur.poste + " " + mon2Chercheur.ordinateur);

//NB : Vous pouvez utiliser la méthode toString() .
        System.out.println(mon1Chercheur.toString());

//16-	Afficher le nombre de chercheurs créés.
        System.out.println("Nombre de chercheurs crées = " + Chercheur.nbrChercheurs);

//17-	 Ajouter dans la classe Chercheur la méthode comparer() qui permet de tester l’égalité entre deux chercheurs : public void comparer (Chercheur ch){…}
        boolean result;
        Chercheur monResult = new Chercheur();
        result = monResult.Compare(mon1Chercheur.nom, mon2Chercheur.nom);
        System.out.println("Les chercheurs sont egaux ? --> " + result); // Affiche 42

//19-	Modifier le numéro de l’ordinateur de l’objet  chercheur1

        mon1Chercheur.ordinateur = 20000;
        System.out.println(mon1Chercheur.nom + " " + mon1Chercheur.poste + " " + mon1Chercheur.ordinateur);
//20-	Créer un objet chercheur3 sans paramètres

        Chercheur chercheur3;

//21-	Ajouter un nom, un poste et un numéro de l’ordinateur à l’objet chercheur3

        chercheur3 = new Chercheur("Sanchez", "secretaire", 00003);
        System.out.println(chercheur3.nom + " " + chercheur3.poste + " " + chercheur3.ordinateur);
        System.out.println("Nombre de chercheurs crées = " + Chercheur.nbrChercheurs);
        
//22-	Créer deux Bureaux bureau1 et bureau2, chaque bureau contient 3 chercheurs
 
        Bureau bureau1 = new Bureau("Bureau 1", 1);
        Bureau bureau2 = new Bureau("Bureau 2", 2);
        bureau1.ajouterChercheur(mon1Chercheur);
        bureau1.ajouterChercheur(mon2Chercheur);
        bureau1.ajouterChercheur(chercheur3);
        bureau2.ajouterChercheur(new Chercheur("Perez", "Assistante", 11));
        bureau2.ajouterChercheur(new Chercheur("Lopez", "Assistante", 12));
        bureau2.ajouterChercheur(new Chercheur("Sanchez", "Assistant", 13));
//22- Créer un Laboratoire laboratoire1 qui contient deux bureaux.

Laboratoire lab1 = new Laboratoire("Lab 1", "Informatique");
        lab1.ajouterBureau(bureau1);
        lab1.ajouterBureau(bureau2);
//23- Afficher les caractéristiques de l’objet laboratoire1.
        System.out.println(lab1.toString());
        System.out.println(bureau1.toString());    
    }
   
}
