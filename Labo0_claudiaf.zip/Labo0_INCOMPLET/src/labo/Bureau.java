
package labo;

public class Bureau {
   public String nom;
    public int code;
    public static final int NB_MAX_CHERCHEUR = 5;
    public Chercheur[] chercheurs = new Chercheur[NB_MAX_CHERCHEUR];
    public int nbChercheur;

    public Bureau(String nom, int code) {
        this.nom = nom;
        this.code = code;
    }

    public void setChercheurs(Chercheur[] chercheurs) {
        this.chercheurs = chercheurs;
    }

    public void setNbChercheur(int nbChercheur) {
        this.nbChercheur = nbChercheur;
    }

    public Chercheur[] getChercheurs() {
        return chercheurs;
    }

    public int getNbChercheur() {
        return nbChercheur;
    }

    public int getCode() {
        return code;
    }

    public String getNom() {
        return nom;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Bureau other = (Bureau) obj;
        if (this.code != other.code) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Bureau{" + "nom=" + nom + " code=" + code + '}';
    }

    public boolean ajouterChercheur(Chercheur chercheur) {
        if (nbChercheur < NB_MAX_CHERCHEUR) {
            chercheurs[nbChercheur] = chercheur;
            nbChercheur++;
            return true;
        } else {
            return false;
        }
    }

    public int trouverChercheur(Chercheur chercheur) {
        for (int i = 0; i < nbChercheur; i++) {
            if (chercheurs[i].equals(chercheur)) {
                return i;
            }
        }
        return -1;
    }

    public boolean supprimerChercheur(Chercheur chercheur) {
        if (trouverChercheur(chercheur) > 0) {
            chercheurs[trouverChercheur(chercheur)] = null;
            nbChercheur--;
            return true;
        }
        return false;
    }

    public static Bureau compare(Bureau bureau1, Bureau bureau2) {
        if (bureau1.getNbChercheur() > bureau2.getNbChercheur()) {
            return bureau1;
        } else {
            return bureau2;
        }
    }
}
