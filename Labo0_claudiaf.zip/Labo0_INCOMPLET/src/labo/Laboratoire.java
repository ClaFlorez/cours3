/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package labo;

/**
 *
 * @author H0PPR202
 */
public class Laboratoire {
     public static final int NB_MAX_BUREAU = 50;//Constante, ne peut pas être modifié
    public String nom;
    public String specialite;
    public Bureau[] bureaux = new Bureau[NB_MAX_BUREAU];
    public int nbBureau;

    //Constructeur par défaut
    public Laboratoire() {
    }

    //Constructeur paramétré (surchargé)
    public Laboratoire(String nom, String specialite) {
        this.nom = nom;
        this.specialite = specialite;
    }


    //redéfinition de la méthode "equals"
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Laboratoire)//obj non null de type Laboratoire
        {
            return (this.nom.equals(((Laboratoire) obj).nom) && this.specialite.equals(((Laboratoire) obj).specialite));
        } else {
            return false;
        }
    }

     //redéfinition de la méthode "equals"
    @Override
    public String toString() {
        return "Laboratoire: {" + "nom=" + nom + " specialite=" + specialite + '}';
    }

    public boolean ajouterBureau(Bureau bureau) {
        if (nbBureau < NB_MAX_BUREAU) {
            bureaux[nbBureau] = bureau;
            nbBureau++;
            return true;
        } else {
            return false;
        }
    }

    public Bureau chercherMinBureau() {

        int min = 0;
        for (int i = 0; i < nbBureau; i++) {
            if (bureaux[i].getNbChercheur() < min) {
                min = i;
            }
        }
        return bureaux[min];
    }

    public boolean ajouterChercheur(Chercheur chercheur) {
        System.out.println(chercherMinBureau().getNom());
        return chercherMinBureau().ajouterChercheur(chercheur);
    }
}
