
package labo;

public class Adresse {

    public int codePostal;
    public String gouvernorat;
    public String ville;
    
    public Adresse() {
    }
    
    public Adresse(int codePostal, String gouvernorat, String ville) {
        this.codePostal = codePostal;
        this.gouvernorat = gouvernorat;
        this.ville = ville;
    }

    public Adresse(int codePostal, String ville) {
        this.codePostal = codePostal;
        this.ville = ville;
    }

   
    
}
