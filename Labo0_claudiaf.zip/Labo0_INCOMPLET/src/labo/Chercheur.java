package labo;

public class Chercheur {

    String nom;
    String poste;
    int ordinateur;
    static int nbrChercheurs;

    @Override
    public String toString() {
        return "Chercheur{"
                + "nom='" + nom + '\''
                + ", poste=" + poste + '\''
                + ", ordinateur=" + ordinateur
                + '}';
    }

    public Chercheur(String nom, String poste, int ordinateur) {
        this.nom = nom;
        this.poste = poste;
        this.ordinateur = ordinateur;
        nbrChercheurs++;
    }

    public Chercheur(String nom) {
        this.nom = nom;
        nbrChercheurs++;
    }

    public Chercheur() {
    }

    

/*essaie avec retourner un message
 * public String Compare (String Chercheur1, String Chercheur2) {
        boolean egaux = false;
        String comp_Chercheur1 = Chercheur1;
        String comp_Chercheur2 = Chercheur2;

        if (comp_Chercheur1 == comp_Chercheur2) {
            egaux = true;
        } else {
            egaux = false;
        }
        System.out.println(egaux);
        return "Persona{" + "les deux chercheur ont le même nom='" + egaux + '}';
    }

*/
public boolean Compare (String Chercheur1, String Chercheur2) {
        boolean egaux = false;
        String comp_Chercheur1 = Chercheur1;
        String comp_Chercheur2 = Chercheur2;

        if (comp_Chercheur1 == comp_Chercheur2) {
            egaux = true;
        } else {
            egaux = false;
        }
       
        return egaux;
        

    }



}