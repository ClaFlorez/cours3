/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propinacalculadora;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JTextField;

/**
 *
 * @author H0PPR202
 */
public class MyFocusListener implements FocusListener {
   private JTextField textField;
    
   
     @Override
        public void focusGained(FocusEvent e) {
            textField.selectAll(); // Sombrear todo el texto
        }

        @Override
        public void focusLost(FocusEvent e) {
            textField.selectAll(); // Sombrear todo el 
        }

   
}
