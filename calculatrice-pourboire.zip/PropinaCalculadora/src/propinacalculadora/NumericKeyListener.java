/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propinacalculadora;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * import javax.swing.*;
 *
 * @author Claudia
 */
public class NumericKeyListener implements KeyListener {

    private JTextField textField;

    public NumericKeyListener(JTextField textField) {
        this.textField = textField;
    }

    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if (!Character.isDigit(c)) {
            e.consume(); // Ignorar el evento de teclado
          /* les lignes suivantes un autre fa]on d<afficher l<erreur
           * String mensajeError = "Erreur";
            int opcion = JOptionPane.showOptionDialog(null,
                    mensajeError,
                    "Error",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.ERROR_MESSAGE,
                    null,
                    null,
                    null);*/
            JOptionPane.showMessageDialog(null, "Erreur",null, JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
}